															Readme APD
															 -TEMA2-
	Idee: tema reprezinta,in realitate,o versiune producer-consumer circulara (in care producatorul e si 
consumator si producator,si vice-versa pentru consumator).Astfel,vom avea in channel-ul comun
pentru Wizzard si Miners 2 buffere(liste de mesaje) reprezentand cele 2 canale disponibile
(cate unul pentru fiecare tip mentionat anterior).Intrucat operatiile din canalul Miners este 
doar un exemplu de producer-consumer,nu vom intra in detalii suplimentare (am folosit doar notifyall si wait
intr-o bucla while)														
	Dificultatea centrala a temei a constat in modul in care sincronizam threadurile de Wizzard,respectiv
cele de Miners pentru a trimite/citi din canalul Wizzards cate 2 mesaje unul dupa altul.
Am realizat acest lucru tinand cont,la fiecare pas,de thread_id-ul local al celui care are voie sa 
puna/citeasca, cat si de un contor care sa permita resetarea ,dupa ce o pereche(current_room,next_room)
a fost procesata de catre un Wizzard/Miner(am realizat acest lucru cu notifyall si wait.A se urmari
explicatiile punctuale din cod).

	Optimizari efectuate: 
1)Tinem un hashSet in channel pentru a nu pune in canalul destinat Wizzards 
acele camere care deja au fost deblocate anterior de catre un alt Wizzard.Astfel ,in functia de 
putMessageWizardChannel verificam daca next_room este in acest hashSet,iar daca este stergem inainte
sa dam notifyall cele 2 mesaje aferente,puse in list_wizzard (pentru a evita primirea acestei perechi 
de catre un miner si verificare ulterioara a acesteia cu hashSet ul global al Minerilor).

2)In run-ul din Miner,cand verificam daca next_room exista deja in solved,pentru a nu tine ocupat
hashSet-ul cat timp compunem functia de hash,folosim doar un boolean pentru a vedea daca exista sau
nu,doar in caz negativ  realizandu-se calcularea hash-ul corespunzator (si asta in afara blocului
in care am sincronizat pe solved).

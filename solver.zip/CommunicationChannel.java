import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Class that implements the channel used by wizards and miners to communicate.
 */
public class CommunicationChannel {
	//numarul maxim de mesaje pe care il poate avea lista minerilor la un moment dat
	//In realitate,MAX_MINERS nu va fi sigur mai mare ca numarul de camere,insa cum nu
	//cunoastem aceasta informatie,presupunem o limita cat mai mare.
	private final int MAX_MINERS = Integer.MAX_VALUE;
	//numarul maxim de mesaje pe care il poate avea lista minerilor la un moment dat
	private final int MAX_WIZZARDS = Integer.MAX_VALUE;

	//un hashSet in care vom tine camerele deblocate de Wizzard
	private HashSet<Integer> set;

	//Cele 2 liste in care se vor tine mesajele
	private volatile ArrayList<Message> list_wizzard;
	private volatile ArrayList<Message> list_miners;
	//contor pentru a putea contoriza perechile de mesaje trimise de acelasi Wizzard/
	//citite de acelasi Miner la un moment dat
	private volatile int contor_wizzard;
	//thread_id ul acelui Wizzard/Miner care are voie sa scrie/citeasca in list_wizzard
	//la un moment dat
	private volatile long current_thread_wizzard;

	/**
	 * Creates a {@code CommunicationChannel} object.
	 */
	public CommunicationChannel() {
		this.list_miners = new ArrayList<>();
		this.list_wizzard = new ArrayList<>();
		this.set = new LinkedHashSet<>();
		current_thread_wizzard = -1;
		contor_wizzard = 0;
	}

	/**
	 * Puts a message on the miner channel (i.e., where miners write to and wizards
	 * read from).
	 * 
	 * @param message
	 *            message to be put on the channel
	 */
	public void putMessageMinerChannel(Message message) {


		synchronized (list_miners){
			while(list_miners.size() == MAX_MINERS){
				try{
					list_miners.wait();
				}catch(Exception e){ }
			}
			list_miners.add(message);
			list_miners.notifyAll();
		}
		
		
	}

	/**
	 * Gets a message from the miner channel (i.e., where miners write to and
	 * wizards read from).
	 * 
	 * @return message from the miner channel
	 */
	public Message getMessageMinerChannel() {
		Message message;

		synchronized (list_miners){
			while(list_miners.size() == 0){
				try{
					list_miners.wait();
				}catch(Exception e){ }
			}
			message = list_miners.remove(0);
			list_miners.notifyAll();
		}
		return message;

	}

	/**
	 * Puts a message on the wizard channel (i.e., where wizards write to and miners
	 * read from).
	 * 
	 * @param message
	 *            message to be put on the channel
	 */
	public void putMessageWizardChannel(Message message) {
		
		if(message.getData().equals("END"))
			return;

		else {
			synchronized (list_wizzard) {
				//cat timp exista un Wizzard care a scris deja primul mesaj din perechea(parent_room,next_room) si Thread_idul curent
				//nu e egal cu thread_idul acelui Wizzard sau lista_wizzard e ocupata total,apelam wait.
				while ((current_thread_wizzard != -1 && current_thread_wizzard != Thread.currentThread().getId()) || list_wizzard.size() == MAX_WIZZARDS) {
					try {
						list_wizzard.wait();
					} catch (Exception e) { }
				}

				list_wizzard.add(message);

				//daca am primit un mesaj de tip EXIT,mentinem current_thread_wizzard pentru a-i permite doar acestuia
				//sa trimita toate mesajele de tip EXIT.
				if (message.getData().equals("EXIT")) {
					contor_wizzard = 0;
					current_thread_wizzard = Thread.currentThread().getId();
				}
				//altfel,daca trimit primul mesaj din perechea (parent_room,next_room),setez current_thread_wizzard
				//pentru a permite doar acestui wizzard sa puna  si celalalt mesaj din pereche imediat dupa primul
				//in lista_wizzard
				else if (contor_wizzard == 0) {
					contor_wizzard = 1;
					current_thread_wizzard = Thread.currentThread().getId();
				}
				//atlfel,daca trimit cel de al 2 mesaj din perechea (parent_room,next_room),resetam atat contorul
				//cat si current_thread_wizzard si notificam toti wizzards ca pot procesa urmatoarea pereche.
				else if (contor_wizzard == 1) {
					contor_wizzard = 0;
					current_thread_wizzard = -1;

					//daca next_room din mesajul Wizzardului curent se gaseste in set,sterg cele 2 mesaje puse de acest
					//Wizzard din list_wizzard (scopul este de a reduce overheadul)
					if (set.contains(message.getCurrentRoom())) {
						int size = list_wizzard.size();
						list_wizzard.remove(size - 1);
						list_wizzard.remove(size - 2);
					}
					//altfel,adaugam next_room in set.
					else
						set.add(message.getCurrentRoom());

					list_wizzard.notifyAll();
				}

			}
		}
		
	}

	/**
	 * Gets a message from the wizard channel (i.e., where wizards write to and
	 * miners read from).
	 * 
	 * @return message from the miner channel
	 */
	public Message getMessageWizardChannel() {
		
		synchronized (list_wizzard){
			while( (current_thread_wizzard != -1 && current_thread_wizzard!= Thread.currentThread().getId()) || list_wizzard.size() == 0){
				try {
					list_wizzard.wait();
				}catch(Exception e){ }
			}
			Message message = list_wizzard.remove(0);

			//daca un miner a primit mesaj de tip EXIT,reinitializeaza current_thread_wizzard si contor_wizzard pentru
			//a permite si celorlalti Mineri sa primeasca mesajul de oprire.
			if(message.getData().equals("EXIT")){
				contor_wizzard = 0;
				current_thread_wizzard = -1;
				list_wizzard.notifyAll();
			}
			//altfel,daca am primit primul mesaj din perechea (parent_room,next_room),setez current_thread_wizzard
			//pentru a permite doar acestui miner sa primeasca si celalalt mesaj din pereche(aflat imediat deasupra in list_wizzard).
			else if(contor_wizzard == 0){
				contor_wizzard = 1;
				current_thread_wizzard = Thread.currentThread().getId();
			}
			//atlfel,daca am primit deja cele 2 mesaje din perechea (parent_room,next_room),resetam atat contorul
			//cat si current_thread_wizzard si notificam toti minerii ca pot procesa urmatoarea pereche.
			else if(contor_wizzard == 1){
				contor_wizzard = 0;
				current_thread_wizzard = -1;
				list_wizzard.notifyAll();
			}
			return message;
		}

	}
		
	
}

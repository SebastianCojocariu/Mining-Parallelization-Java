import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Set;

/**
 * Class for a miner.
 */
public class Miner extends Thread {
	/**
	 * Creates a {@code Miner} object.
	 * 
	 * @param hashCount
	 *            number of times that a miner repeats the hash operation when
	 *            solving a puzzle.
	 * @param solved
	 *            set containing the IDs of the solved rooms
	 * @param channel
	 *            communication channel between the miners and the wizards
	 */

	private int hashCount;
	private volatile Set<Integer> solved;
	private CommunicationChannel channel;


	public Miner(Integer hashCount, Set<Integer> solved, CommunicationChannel channel) {
		this.hashCount = hashCount;
		this.solved = solved;
		this.channel = channel;
	}

	private static String encryptMultipleTimes(String input, Integer count) {
		String hashed = input;
		for (int i = 0; i < count; ++i) {
			hashed = encryptThisString(hashed);
		}

		return hashed;
	}

	private static String encryptThisString(String input) {
		try {
			MessageDigest md = MessageDigest.getInstance("SHA-256");
			byte[] messageDigest = md.digest(input.getBytes(StandardCharsets.UTF_8));

			// convert to string
			StringBuffer hexString = new StringBuffer();
			for (int i = 0; i < messageDigest.length; i++) {
				String hex = Integer.toHexString(0xff & messageDigest[i]);
				if(hex.length() == 1) hexString.append('0');
				hexString.append(hex);
			}
			return hexString.toString();

		} catch (NoSuchAlgorithmException e) {
			throw new RuntimeException(e);
		}
	}


	@Override
	public void run() {

		//cat timp nu am primit mesajul de tip EXIT de la Wizzards citim 2 mesaje din lista de
		//mesaje trimise de Wizzards si verificam daca next_room din ultimul mesaj exista
		//deja in solved.Daca exista,nu fac nimic,altfel compun hashul si trimit mesajul
		//corespunzator pe canalul destinat minerilor pentru a fi procesat de un Wizzard
		//Pentru a nu tine solved ocupat,folosim o variabila de tip boolean pentru a vedea
		//daca exista sau nu next_room,iar in cazul in care nu exista abia atunci compunem
		//hashul corespunzator(dar asta realizandu se inafara blocului synchronized(solved))
		while(true){
			Message msg1 = channel.getMessageWizardChannel();
			int current_room = msg1.getCurrentRoom();
			String encode_current_room = msg1.getData();

			if(encode_current_room.equals("EXIT")) {
				break;
			}

			Message msg2 = channel.getMessageWizardChannel();
			int next_room = msg2.getCurrentRoom();
			String encode_next_room = msg2.getData();

			if(encode_current_room.equals("EXIT")) {
				break;
			}

			//daca s a ajuns aici inseamna ca am primit o pereche(current_room,next_room)
			//verificam daca next_room e in solved sau nu.
			boolean exists = false;
			synchronized (solved) {
				if (!solved.contains(next_room)){
					exists = true;
					solved.add(next_room);
				}
			}
			//daca exists == true,compunem hashul si scriem mesajul pe canalul minerilor.
			if(exists) {
				//compute hash
				String hashed = encryptMultipleTimes(encode_next_room,hashCount);
				channel.putMessageMinerChannel(new Message(current_room,next_room,hashed));
			}

		}
	}
}
